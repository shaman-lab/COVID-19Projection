function outputprojection()
load ('../infer_and_projection/Projection_extend.mat');

outputinci(obs_proj_season4,infection_proj_season4,death_proj_season4,'../output/Projection_season4.csv');
outputinci(obs_proj_5_1xhold,infection_proj_5_1xhold,death_proj_5_1xhold,'../output/Projection_5_1xhold.csv');
outputinci(obs_proj_5_2xhold,infection_proj_5_2xhold,death_proj_5_2xhold,'../output/Projection_5_2xhold.csv');
outputinci(obs_proj_5_1x,infection_proj_5_1x,death_proj_5_1x,'../output/Projection_5_1x.csv');


function outputinci(obs_proj,infection_proj,death_proj,filename)
load countyfips
data=obs_proj;
data1=infection_proj;
data2=death_proj;
num_times=size(data,3);
num_loc=size(data,1);
T0=datetime('21/02/20','InputFormat','dd/MM/yy');
fid=fopen(filename,'w');
header=['county,fips,Date,confirmed_2.5,confirmed_25,confirmed_50,confirmed_75,confirmed_97.5'];
header=[header,',infection_2.5,infection_25,inection_50,infection_75,infection_97.5'];
header=[header,',death_2.5,death_25,death_50,death_75,death_97.5\n'];
fprintf(fid,header);
load ('../infer_and_projection/dailyincidence.mat');
T_proj=size(dailyincidence,2);

for t=T_proj+1:num_times
    t
    for i=1:num_loc
        fprintf(fid,'%s,%s,%s',countyfips{i,2}{1},countyfips{i,3}{1},datestr(T0+t-1,'mm/dd/yy'));
        temp=squeeze(data(i,:,t));
        mid=round(median(temp));llow=round(prctile(temp,2.5));low=round(prctile(temp,25));
        up=round(prctile(temp,75));upp=round(prctile(temp,97.5));
        fprintf(fid,',%d,%d,%d,%d,%d',llow,low,mid,up,upp);
        temp=squeeze(data1(i,:,t));
        mid=round(median(temp));llow=round(prctile(temp,2.5));low=round(prctile(temp,25));
        up=round(prctile(temp,75));upp=round(prctile(temp,97.5));
        fprintf(fid,',%d,%d,%d,%d,%d',llow,low,mid,up,upp);
        temp=squeeze(data2(i,:,t));
        mid=round(median(temp));llow=round(prctile(temp,2.5));low=round(prctile(temp,25));
        up=round(prctile(temp,75));upp=round(prctile(temp,97.5));
        fprintf(fid,',%d,%d,%d,%d,%d',llow,low,mid,up,upp);
        fprintf(fid,'\n');
    end

end
fclose(fid);