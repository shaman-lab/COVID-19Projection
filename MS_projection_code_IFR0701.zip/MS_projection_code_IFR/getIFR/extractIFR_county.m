function extractIFR_county(updatedate)
%download csv

URL=['https://www.cdc.gov/coronavirus/2019-ncov/covid-data/covidview/',updatedate,'/csv/commercial-lab.csv'];
urlwrite (URL, 'commercial-lab.csv');
opts = detectImportOptions('commercial-lab.csv');
opts = setvartype(opts, {'Var7','Var10','Var13','Var16','Var19'}, 'string');  %or 'char' if you prefer
T=readtable('commercial-lab.csv',opts);
infectioncase=zeros(12,5,10);
cntregion=0;
for i=18:size(T,1)
    if T{i,1}==202014
        cntregion=cntregion+1;
    end
    if (T{i,1}>=202014)
        weeknum=T{i,1}-202014+1;
        for j=1:5
            
            temp=T{i,7+(j-1)*3}{1};
            temp=strrep(temp,',','');
            inci=str2num(temp);
            infectioncase(weeknum,j,cntregion)=inci;
        end
        
    end

end

load agepop_county
%age IFR
IFR_9agegroup=[0.00161;0.00695;0.0309;0.0844;0.161;0.595;1.93;4.28;7.8]/100;
IFR_age=zeros(5,3142);
for l=1:3142
    agepop=agepop_county(:,l);
    IFR_age(1,l)=IFR_9agegroup(1);%0-4
    total=sum(agepop(2:4));
    IFR_age(2,l)=IFR_9agegroup(1)*agepop(2)/total+IFR_9agegroup(2)*(agepop(3)+agepop(4))/total;%5-17
    total=sum(agepop(5:10));
    IFR_age(3,l)=IFR_9agegroup(3)*(agepop(5)+agepop(6))/total+IFR_9agegroup(4)*(agepop(7)+agepop(8))/total...
        +IFR_9agegroup(5)*(agepop(9)+agepop(10))/total;%18-49
    total=sum(agepop(11:13));
    IFR_age(4,l)=IFR_9agegroup(6)*(agepop(11)+agepop(12))/total+IFR_9agegroup(7)*(agepop(13))/total;%50-64
    total=sum(agepop(14:18));
    IFR_age(5,l)=IFR_9agegroup(7)*(agepop(14))/total+IFR_9agegroup(8)*(agepop(15)+agepop(16))/total...
        +IFR_9agegroup(9)*(agepop(17)+agepop(18))/total;%65+
end

IFR=zeros(3142,12);
load inregion
for l=1:3142
    for t=1:12
        region=inregion(l);
        age=infectioncase(t,:,region);
        weight=age/sum(age);
        IFR(l,t)=weight*IFR_age(:,l);
    end
end

num_weeks=size(IFR,2);
T0=datetime('21/02/20','InputFormat','dd/MM/yy');
Tstart=datetime('29/03/20','InputFormat','dd/MM/yy');

T1=datenum(Tstart)-datenum(T0);
Tend=T1+7*num_weeks;

num_loc=3142;

deathrate=zeros(num_loc,Tend);
%until T1
for l=1:num_loc
    deathrate(l,1:T1)=IFR(l,1);
end

for t=T1+1:Tend
    week=ceil((t-T1)/7);
    deathrate(:,t)=IFR(:,week);
end

save ('../infer_and_projection/deathrate_IFR.mat','deathrate')
