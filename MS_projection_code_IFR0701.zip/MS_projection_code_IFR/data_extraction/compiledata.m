function compiledata()
%day 1 is 22/01/20 in csv
%output file starts from 21/02/20
countydata = readtable('covid_confirmed_usafacts.csv');
countydata = countydata(2:size(countydata,1),:);
load countyfips_num
num_loc=size(countyfips_num,1);
num_times=size(countydata,2)-4;
dailyincidence=zeros(num_loc,num_times);

for i=1:size(countydata,1)
    i
    fips=countydata{i,1};
    if fips==2270%Wade Hampton Census Area AK
        fips=2158;%Kusilvak Census Area AK
    end
    if fips==46113%Shannon County SD
        fips=46102;%Oglala Lakota County SD
    end
    if fips==51515%Bedford city VA
        fips=51019;%Bedford County VA
    end
    
    countyid=0;
    for j=1:size(countyfips_num,1)
        fips1=countyfips_num(j);
        if fips==fips1
            countyid=j;
            break
        end
    end
    if (countyid==0)&&(fips~=0)&&(fips~=6000)
        countydata{i,2}
        countydata{i,3}
        if strcmpi(countydata{i,2},'New York City Unallocated/Probable')
            continue
        else
            pause
        end
    end
    if countyid>0
        data=countydata{i,5:end};
        dailycase=zeros(1,num_times);
        dailycase(1)=data(1);
        for t=2:num_times
            dailycase(t)=max(data(t)-data(t-1),0);  
        end
        dailyincidence(countyid,:)=dailyincidence(countyid,:)+dailycase;
    end
end

T0=datetime('22/01/20','InputFormat','dd/MM/yy');
Tstart=datetime('21/02/20','InputFormat','dd/MM/yy');

T0datenum=datenum(T0);
Tstartdatenum=datenum(Tstart);
diff=Tstartdatenum-T0datenum;

dailyincidence=dailyincidence(:,1+diff:end);

save ('../infer_and_projection/dailyincidence.mat','dailyincidence')