function infer()
% mex model_eakf.cpp
Td=9;%average reporting delay
a=1.85;%shape parameter of gamma distribution
b=Td/a;%scale parameter of gamma distribution
rnds=ceil(gamrnd(a,b,1e4,1));%pre-generate gamma random numbers

Td_death=9+7;%average delay of death
a=1.85;%shape parameter of gamma distribution
b=Td_death/a;%scale parameter of gamma distribution
rnds_d=ceil(gamrnd(a,b,1e4,1));%pre-generate gamma random numbers

load commutedata
load population
num_loc=size(part,1)-1;
num_mp=size(nl,1);

load dailyincidence
load dailydeaths
num_times=size(dailyincidence,2);%total length of data
%smooth the data: 7 day moving average
for l=1:num_loc
    for t=1:num_times
        dailyincidence(l,t)=mean(dailyincidence(l,max(1,t-3):min(t+3,num_times)));
        dailydeaths(l,t)=mean(dailydeaths(l,max(1,t-3):min(t+3,num_times)));
    end
end

load deathrate_IFR%Case Fataltiy rate during lastest two weeks
T=num_times+6*7;%projection for 6 weeks
obs_case=dailyincidence;
obs_death=dailydeaths;
incidence=dailyincidence(:,1:22);%from 02/21 to 03/13, to initialize

%set OEV
OEV_case=zeros(size(dailyincidence));
OEV_death=zeros(size(dailydeaths));
for l=1:num_loc
    for t=1:num_times
        obs_ave=mean(dailyincidence(l,max(1,t-6):t));
        OEV_case(l,t)=max(1,obs_ave^2/25);
        death_ave=mean(dailydeaths(l,max(1,t-6):t));
        OEV_death(l,t)=max(1,death_ave^2/25);
    end
end


%adjusting inter-county movement
load MI_inter
%adjusting mobility starting from March 16, day 25
MI_inter_relative=MI_inter(:,2:end);
for t=25:size(MI_inter_relative,2)
    MI_inter_relative(:,t)=MI_inter_relative(:,t)./MI_inter_relative(:,t-1);
    MI_inter_relative(isnan(MI_inter_relative(:,t)),t)=0;
    MI_inter_relative(isinf(MI_inter_relative(:,t)),t)=0;
    MI_inter_relative(:,t)=min(MI_inter_relative(:,t),1);
end
MI_inter_relative(:,1:24)=1;

C=C*ones(1,T);
Cave=Cave*ones(1,T);
for t=25:T%day 25: March 16
    C(:,t)=C(:,t-1);
    Cave(:,t)=Cave(:,t-1);
    for l=1:num_loc
        for j=part(l)+1:part(l+1)-1
            if t<=size(MI_inter_relative,2)
                C(part(l),t)=C(part(l),t)+((1-MI_inter_relative(nl(j),t))*C(j,t));
                Cave(part(l),t)=Cave(part(l),t)+((1-MI_inter_relative(nl(j),t))*Cave(j,t));
                C(j,t)=(MI_inter_relative(nl(j),t)*C(j,t));
                Cave(j,t)=(MI_inter_relative(nl(j),t)*Cave(j,t));
            end
        end
    end
end

num_ens=100;%number of ensemble
infection_proj=zeros(num_loc,num_ens,T);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%run model unitl March 10, day 19
[S,E,Ir,Iu,Seedc]=initialize(nl,part,C(:,1),num_ens,incidence);
obs_temp=zeros(num_loc,num_ens,T);%records of reported cases
death_temp=zeros(num_loc,num_ens,T);%records of death
load('parafit1')
%initialize parameters
[para,paramax,paramin,betamap,alphamaps]=initializepara_eakf(dailyincidence,num_ens,parafit);
%%%%%%%%%%%%inflate variables and parameters
lambda=2;
para=mean(para,2)*ones(1,num_ens)+lambda*(para-mean(para,2)*ones(1,num_ens));
para=checkbound_para(para,paramax,paramin);
E=mean(E,2)*ones(1,num_ens)+lambda*(E-mean(E,2)*ones(1,num_ens));
Ir=mean(Ir,2)*ones(1,num_ens)+lambda*(Ir-mean(Ir,2)*ones(1,num_ens));
Iu=mean(Iu,2)*ones(1,num_ens)+lambda*(Iu-mean(Iu,2)*ones(1,num_ens));
[S,E,Ir,Iu]=checkbound(S,E,Ir,Iu,C);
%fix Z, D and theta
%Z
para(1,:)=parafit(3,1:num_ens);
%D
para(2,:)=parafit(4,1:num_ens);
%mu
para(3,:)=parafit(2,1:num_ens);
%theta
para(4,:)=parafit(6,1:num_ens);

parastd=std(para,0,2);

for t=1:22%run unitl March 13
    t
    tic
    %%%%%%%%%%%seeding
    if t<=size(Seedc,2)
        [S,E,Ir,Iu]=seeding(S,E,Ir,Iu,nl,part,C(:,t),Seedc,t);
    end
    for k=1:num_ens
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C(:,t),Cave(:,t),S(:,k),E(:,k),Ir(:,k),Iu(:,k),para(:,k),betamap,alphamaps);
        for l=1:num_loc
            infection_proj(l,k,t)=min(sum(dailyIr_temp(part(l):part(l+1)-1))+sum(dailyIu_temp(part(l):part(l+1)-1)),500);
        end
        %reporting delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=min(dailyIr_temp(j),100);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_temp(l,k,t+rnd(h))=obs_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %death delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=min(round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l,min(t,size(deathrate,2)))),10);
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_temp(l,k,t+rnd(h))=death_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end
    toc
end

%EAKF
lambda=1.2;%inflation
num_para=size(para,1);
para_post=zeros(num_para,num_ens,num_times);
for t=23:num_times-6%start from March 14, and stop 6 days before the latest date
    t
    tic
    %fix Z, D and theta
    %Z
    para(1,:)=parafit(3,1:num_ens);
    %D
    para(2,:)=parafit(4,1:num_ens);
    %mu
    para(3,:)=parafit(2,1:num_ens);
    %theta
    para(4,:)=parafit(6,1:num_ens);
    %%%%%%%%%%%%%%%%%%
    S_temp=S; E_temp=E; Ir_temp=Ir; Iu_temp=Iu;
    %integrate forward one step
    dailyIr_prior=zeros(num_mp,num_ens);
    dailyIu_prior=zeros(num_mp,num_ens);
    for k=1:num_ens%run for each ensemble member
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k)]=adjustmobility(S(:,k),E(:,k),Ir(:,k),Iu(:,k),nl,part,MI_inter_relative,t);
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C(:,t),Cave(:,t),S(:,k),E(:,k),Ir(:,k),Iu(:,k),para(:,k),betamap,alphamaps);
        dailyIr_prior(:,k)=dailyIr_temp;
        dailyIu_prior(:,k)=dailyIu_temp;
    end
    %%%%%%%%%%%%%%%%%%%%%%
    %integrate forward for six days, prepare for observation
    Tproj=min(6,num_times-t+1);
    obs_temp1=obs_temp;
    death_temp1=death_temp;
    for t1=t:t+Tproj-1
        for k=1:num_ens%run for each ensemble member
            [S_temp(:,k),E_temp(:,k),Ir_temp(:,k),Iu_temp(:,k)]=adjustmobility(S_temp(:,k),E_temp(:,k),Ir_temp(:,k),Iu_temp(:,k),nl,part,MI_inter_relative,t1);
            [S_temp(:,k),E_temp(:,k),Ir_temp(:,k),Iu_temp(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C(:,t1),Cave(:,t1),S_temp(:,k),E_temp(:,k),Ir_temp(:,k),Iu_temp(:,k),para(:,k),betamap,alphamaps);
            %reporting delay
            for l=1:num_loc
                for j=part(l):part(l+1)-1
                    inci=dailyIr_temp(j);
                    if inci>0
                        rnd=datasample(rnds,inci);
                        for h=1:length(rnd)
                            if (t1+rnd(h)<=T)
                                obs_temp1(l,k,t1+rnd(h))=obs_temp1(l,k,t1+rnd(h))+1;
                            end
                        end 
                    end
                end
            end
            %death delay
            for l=1:num_loc
                for j=part(l):part(l+1)-1
                    inci=round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l,min(t1,size(deathrate,2))));
                    if inci>0
                        rnd=datasample(rnds_d,inci);
                        for h=1:length(rnd)
                            if (t1+rnd(h)<=T)
                                death_temp1(l,k,t1+rnd(h))=death_temp1(l,k,t1+rnd(h))+1;
                            end
                        end 
                    end
                end
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for t1=t+Tproj-1
        obs_ens=obs_temp1(:,:,t1);%observation at t1, prior
        death_ens=death_temp1(:,:,t1);%death at t1, prior
        %loop through local observations
        for l=1:num_loc
            %%%%%%%%%%%%%%%%%%%death
            %Get the variance of the ensemble
            obs_var = OEV_death(l,t1);
            prior_var = var(death_ens(l,:));
            post_var = prior_var*obs_var/(prior_var+obs_var);
            if prior_var==0%if degenerate
                post_var=1e-3;
                prior_var=1e-3;
            end
            prior_mean = mean(death_ens(l,:));
            post_mean = post_var*(prior_mean/prior_var + obs_death(l,t1)/obs_var);
            %%%% Compute alpha and adjust distribution to conform to posterior moments
            alpha = (obs_var/(obs_var+prior_var)).^0.5;
            dy = post_mean + alpha*(death_ens(l,:)-prior_mean)-death_ens(l,:);
            %Loop over each state variable (connected to location l)
            %adjust related metapopulation
            neighbors=part(l):part(l+1)-1;%metapopulation live in l
            neighbors1=find(nl==l);%%metapopulation work in l
            neighbors=union(neighbors1,neighbors);
            for h=1:length(neighbors)
                j=neighbors(h);
                %E
                temp=E(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                E(j,:)=E(j,:)+dx;
                %Ir
                temp=Ir(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                Ir(j,:)=Ir(j,:)+dx;
                %Iu
                temp=Iu(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                Iu(j,:)=Iu(j,:)+dx;
                %dailyIr
                temp=dailyIr_prior(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                dailyIr_prior(j,:)=round(max(dailyIr_prior(j,:)+dx,0));
                %dailyIu
                temp=dailyIu_prior(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                dailyIu_prior(j,:)=round(max(dailyIu_prior(j,:)+dx,0));
            end
            %adjust alpha
            temp=para(alphamaps(l),:);
            A=cov(temp,death_ens(l,:));
            rr=A(2,1)/prior_var;
            dx=rr*dy;
            para(alphamaps(l),:)=para(alphamaps(l),:)+dx;
            %inflation
            if std(para(alphamaps(l),:))<parastd(alphamaps(l))
                para(alphamaps(l),:)=mean(para(alphamaps(l),:),2)*ones(1,num_ens)+lambda*(para(alphamaps(l),:)-mean(para(alphamaps(l),:),2)*ones(1,num_ens));
            end
            %adjust beta
            temp=para(betamap(l),:);
            A=cov(temp,death_ens(l,:));
            rr=A(2,1)/prior_var;
            dx=rr*dy;
            para(betamap(l),:)=para(betamap(l),:)+dx;
            %inflation
            if std(para(betamap(l),:))<parastd(betamap(l))
                para(betamap(l),:)=mean(para(betamap(l),:),2)*ones(1,num_ens)+lambda*(para(betamap(l),:)-mean(para(betamap(l),:),2)*ones(1,num_ens));
            end
            
            %%%%%%%%%%%%%%%%%%%case
            %Get the variance of the ensemble
            obs_var = OEV_case(l,t1);
            prior_var = var(obs_ens(l,:));
            post_var = prior_var*obs_var/(prior_var+obs_var);
            if prior_var==0%if degenerate
                post_var=1e-3;
                prior_var=1e-3;
            end
            prior_mean = mean(obs_ens(l,:));
            post_mean = post_var*(prior_mean/prior_var + obs_case(l,t1)/obs_var);
            %%%% Compute alpha and adjust distribution to conform to posterior moments
            alpha = (obs_var/(obs_var+prior_var)).^0.5;
            dy = post_mean + alpha*(obs_ens(l,:)-prior_mean)-obs_ens(l,:);
            %Loop over each state variable (connected to location l)
            %adjust related metapopulation
            neighbors=part(l):part(l+1)-1;%metapopulation live in l
            neighbors1=find(nl==l);%%metapopulation work in l
            neighbors=union(neighbors1,neighbors);
            for h=1:length(neighbors)
                j=neighbors(h);
                %E
                temp=E(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                E(j,:)=E(j,:)+dx;
                %Ir
                temp=Ir(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                Ir(j,:)=Ir(j,:)+dx;
                %Iu
                temp=Iu(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                Iu(j,:)=Iu(j,:)+dx;
                %dailyIr
                temp=dailyIr_prior(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                dailyIr_prior(j,:)=round(max(dailyIr_prior(j,:)+dx,0));
                %dailyIu
                temp=dailyIu_prior(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                dailyIu_prior(j,:)=round(max(dailyIu_prior(j,:)+dx,0));
            end
            %adjust alpha
            temp=para(alphamaps(l),:);
            A=cov(temp,obs_ens(l,:));
            rr=A(2,1)/prior_var;
            dx=rr*dy;
            para(alphamaps(l),:)=para(alphamaps(l),:)+dx;
            %inflation
            if std(para(alphamaps(l),:))<parastd(alphamaps(l))
                para(alphamaps(l),:)=mean(para(alphamaps(l),:),2)*ones(1,num_ens)+lambda*(para(alphamaps(l),:)-mean(para(alphamaps(l),:),2)*ones(1,num_ens));
            end
            %adjust beta
            temp=para(betamap(l),:);
            A=cov(temp,obs_ens(l,:));
            rr=A(2,1)/prior_var;
            dx=rr*dy;
            para(betamap(l),:)=para(betamap(l),:)+dx;
            %inflation
            if std(para(betamap(l),:))<parastd(betamap(l))
                para(betamap(l),:)=mean(para(betamap(l),:),2)*ones(1,num_ens)+lambda*(para(betamap(l),:)-mean(para(betamap(l),:),2)*ones(1,num_ens));
            end
        end
        para=checkbound_para(para,paramax,paramin);
    end
    %update posterior Ir and Iu
    dailyIr_post=dailyIr_prior;
    dailyIu_post=dailyIu_prior;
    
    for k=1:num_ens
        %update obs_temp
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=dailyIr_post(j,k);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_temp(l,k,t+rnd(h))=obs_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %update death_temp
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=round((dailyIr_post(j,k)+dailyIu_post(j,k))*deathrate(l,min(t,size(deathrate,2))));
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_temp(l,k,t+rnd(h))=death_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end

    [S,E,Ir,Iu]=checkbound(S,E,Ir,Iu,C);
    para_post(:,:,t)=para;
    %%%%prepare projection
    for k=1:num_ens
        %total infection
        for l=1:num_loc
            infection_proj(l,k,t)=sum(dailyIr_post(part(l):part(l+1)-1,k))+sum(dailyIu_post(part(l):part(l+1)-1,k));
        end
    end
   toc
end

S_start=S; E_start=E; Ir_start=Ir; Iu_start=Iu;
obs_temp_start=obs_temp;%records of reported cases
death_temp_start=death_temp;%records of reported cases
infection_proj_start=infection_proj;

% 4% reduction
disp ('starting 4% seasonal reduction projection')
reduce=0.04;
S=S_start; E=E_start; Iu=Iu_start; Ir=Ir_start;
obs_proj_season4=obs_temp_start;
death_proj_season4=death_temp_start;
infection_proj_season4=infection_proj_start;
parapost=para_post(:,:,end-6);
paratemp=parapost;
for t=num_times-5:T
    t
    tdiff=t-(num_times+1);
    %reduce beta
    if mod(tdiff,7)==0
        paratemp(betamap,:)=paratemp(betamap,:)*(1-reduce);
    end
    for k=1:num_ens%run for each ensemble member
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k)]=adjustmobility(S(:,k),E(:,k),Ir(:,k),Iu(:,k),nl,part,MI_inter_relative,t);
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C(:,t),Cave(:,t),S(:,k),E(:,k),Ir(:,k),Iu(:,k),paratemp(:,k),betamap,alphamaps);
        [infection_proj_season4,  obs_proj_season4, death_proj_season4]= ...
            delayedobservations(infection_proj_season4,obs_proj_season4, death_proj_season4,num_loc,part,...
            dailyIr_temp,dailyIu_temp,deathrate,k,t,rnds,rnds_d,T);
    end
end

%  1 time 5% increase then hold
disp('starting 1x 5% increase projection then hold')
increaserate=.05;
S=S_start; E=E_start; Iu=Iu_start; Ir=Ir_start;
obs_proj_5_1xhold=obs_temp_start;
death_proj_5_1xhold=death_temp_start;
infection_proj_5_1xhold=infection_proj_start;
parapost=para_post(:,:,end-6);
paratemp=parapost;
paratemp(betamap,:)=paratemp(betamap,:)*(1+increaserate);%   do one time bump
alpha=paratemp(alphamaps,:);
D=paratemp(2,:);
mu=paratemp(3,:);
for t=num_times-5:T
    for c=1:3142
        Scounty(c,:)=sum(S(part(c):part(c+1)-1,:),1);
    end
    t
    for k=1:num_ens%run for each ensemble member
        if t > num_times + 2 % after one week
            % set beta so that Reff=1
            newbeta=population./((Scounty(:,k).*D(k).*(alpha(:,k)+(1-alpha(:,k)).*mu(k))));
            newbeta=min(newbeta,10); % set upper limit to 10, to remove huge values cause by small S
            paratemp(betamap,k)=newbeta;
        end
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k)]=adjustmobility(S(:,k),E(:,k),Ir(:,k),Iu(:,k),nl,part,MI_inter_relative,t);
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C(:,t),Cave(:,t),S(:,k),E(:,k),...
            Ir(:,k),Iu(:,k),paratemp(:,k),betamap,alphamaps);
        [infection_proj_5_1xhold,  obs_proj_5_1xhold, death_proj_5_1xhold]= ...
            delayedobservations(infection_proj_5_1xhold,obs_proj_5_1xhold, death_proj_5_1xhold,num_loc,part,...
            dailyIr_temp,dailyIu_temp,deathrate,k,t,rnds,rnds_d,T);
    end
end

%  2 time 5% increase then hold
disp('starting 2 x 5% increase projection then hold')
increaserate=.05;
S=S_start; E=E_start; Iu=Iu_start; Ir=Ir_start;
obs_proj_5_2xhold=obs_temp_start;
death_proj_5_2xhold=death_temp_start;
infection_proj_5_2xhold=infection_proj_start;
parapost=para_post(:,:,end-6);
paratemp=parapost;
paratemp(betamap,:)=paratemp(betamap,:)*(1+increaserate);%   do the first bump
alpha=paratemp(alphamaps,:);
D=paratemp(2,:);
mu=paratemp(3,:);
for t=num_times-5:T
    t
    for c=1:3142
        Scounty(c,:)=sum(S(part(c):part(c+1)-1,:),1);
    end
    if  t==num_times+2% start of the second week
        paratemp(betamap,:)=paratemp(betamap,:)*(1+increaserate);%   do the second bump
    end
    for k=1:num_ens%run for each ensemble member
        if t > num_times+ 2+ 7 % after one week
            % set beta so that Reff=1
            newbeta=population./((Scounty(:,k).*D(k).*(alpha(:,k)+(1-alpha(:,k)).*mu(k))));
            newbeta=min(newbeta,10);
            paratemp(betamap,k)=newbeta;
        end
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k)]=adjustmobility(S(:,k),E(:,k),Ir(:,k),Iu(:,k),nl,part,MI_inter_relative,t);
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C(:,t),Cave(:,t),S(:,k),E(:,k),...
            Ir(:,k),Iu(:,k),paratemp(:,k),betamap,alphamaps);
        [infection_proj_5_2xhold,  obs_proj_5_2xhold, death_proj_5_2xhold]= ...
            delayedobservations(infection_proj_5_2xhold,obs_proj_5_2xhold, death_proj_5_2xhold,num_loc,part,...
            dailyIr_temp,dailyIu_temp,deathrate,k,t,rnds,rnds_d,T);
    end
end

%  1 time 5% increase
disp('starting 1x 5% increase projection')
increaserate=.05;
S=S_start; E=E_start; Iu=Iu_start; Ir=Ir_start;
obs_proj_5_1x=obs_temp_start;
death_proj_5_1x=death_temp_start;
infection_proj_5_1x=infection_proj_start;
parapost=para_post(:,:,end-6);
paratemp=parapost;
% one time bump
paratemp(betamap,:)=paratemp(betamap,:)*(1+increaserate);
for t=num_times-5:T
    t
    for k=1:num_ens%run for each ensemble member
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k)]=adjustmobility(S(:,k),E(:,k),Ir(:,k),Iu(:,k),nl,part,MI_inter_relative,t);
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C(:,t),Cave(:,t),S(:,k),E(:,k),Ir(:,k),Iu(:,k),paratemp(:,k),betamap,alphamaps);
        [infection_proj_5_1x,  obs_proj_5_1x, death_proj_5_1x]= ...
            delayedobservations(infection_proj_5_1x,obs_proj_5_1x, death_proj_5_1x,num_loc,part,...
            dailyIr_temp,dailyIu_temp,deathrate,k,t,rnds,rnds_d,T);
    end
end

save(['Projection_extend'],'obs_case','obs_death','para_post','obs_temp','death_temp',...
    'obs_proj_season4','infection_proj_season4','death_proj_season4',...
    'obs_proj_5_1xhold','infection_proj_5_1xhold','death_proj_5_1xhold',...
    'obs_proj_5_2xhold','infection_proj_5_2xhold','death_proj_5_2xhold',...
    'obs_proj_5_1x','infection_proj_5_1x','death_proj_5_1x');


function para = checkbound_paraini(para,paramax,paramin)
for i=1:size(para,1)
    temp=para(i,:);
    index=(temp<paramin(i))|(temp>paramax(i));
    index_out=find(index>0);
    index_in=find(index==0);
    %redistribute out bound ensemble members
    para(i,index_out)=datasample(para(i,index_in),length(index_out));
end


function para = checkbound_para(para,paramax,paramin)
for i=1:size(para,1)
    para(i,para(i,:)<paramin(i))=paramin(i)*(1+0.1*rand(sum(para(i,:)<paramin(i)),1));
    para(i,para(i,:)>paramax(i))=paramax(i)*(1-0.1*rand(sum(para(i,:)>paramax(i)),1));
end

function [S,E,Ir,Iu]=checkbound(S,E,Ir,Iu,C)
for k=1:size(S,2)
    S(S(:,k)<0,k)=0; E(E(:,k)<0,k)=0; Ir(Ir(:,k)<0,k)=0; Iu(Iu(:,k)<0,k)=0;
end


function [S,E,Ir,Iu]=adjustmobility(S,E,Ir,Iu,nl,part,MI_inter_relative,t)
num_loc=size(MI_inter_relative,1);
for l=1:num_loc
    for j=part(l)+1:part(l+1)-1
        if t<=size(MI_inter_relative,2)
            S(part(l))=S(part(l))+((1-MI_inter_relative(nl(j),t))*S(j));
            S(j)=(MI_inter_relative(nl(j),t)*S(j));
            E(part(l))=E(part(l))+((1-MI_inter_relative(nl(j),t))*E(j));
            E(j)=(MI_inter_relative(nl(j),t)*E(j));
            Ir(part(l))=Ir(part(l))+((1-MI_inter_relative(nl(j),t))*Ir(j));
            Ir(j)=(MI_inter_relative(nl(j),t)*Ir(j));
            Iu(part(l))=Iu(part(l))+((1-MI_inter_relative(nl(j),t))*Iu(j));
            Iu(j)=(MI_inter_relative(nl(j),t)*Iu(j));
        end
    end
end

function [infectiondata, obsdata, deathdata]= delayedobservations(infectiondata,obsdata,deathdata,num_loc,part,...
    dailyIr_temp,dailyIu_temp,deathrate,k,t,rnds,rnds_d,T)
for l=1:num_loc
    infectiondata(l,k,t)=sum(dailyIr_temp(part(l):part(l+1)-1))+sum(dailyIu_temp(part(l):part(l+1)-1));
end

%reporting delay
for l=1:num_loc
    for j=part(l):part(l+1)-1
        inci=dailyIr_temp(j);
        if inci>0
            rnd=datasample(rnds,inci);
            for h=1:length(rnd)
                if (t+rnd(h)<=T)
                    obsdata(l,k,t+rnd(h))=obsdata(l,k,t+rnd(h))+1;
                end
            end
        end
    end
end
%death delay
for l=1:num_loc
    for j=part(l):part(l+1)-1
        inci=round((dailyIr_temp(j)+dailyIr_temp(j))*deathrate(l,min(t,size(deathrate,2))));
        if inci>0
            rnd=datasample(rnds_d,inci);
            for h=1:length(rnd)
                if (t+rnd(h)<=T)
                    deathdata(l,k,t+rnd(h))=deathdata(l,k,t+rnd(h))+1;
                end
            end
        end
    end
end