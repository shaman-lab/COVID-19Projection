function checkproj()
load Projection_extend
load countyfips
load dailyincidence
load dailydeaths
num_loc=size(countyfips,1);
ranks=zeros(num_loc,2);
ranks(:,1)=(1:num_loc)';
ranks(:,2)=sum(dailyincidence,2);
ranks=sortrows(ranks,-2);
obs_proj=obs_proj_5_2xhold;
figure(1)
locs=ranks(1:1+15,1);
T=size(dailyincidence,2);
T_proj=T+6*7;
for i=1:length(locs)
    subplot(4,4,i)
    temp=squeeze(obs_proj(locs(i),:,:));
    plot(1:T_proj,temp(:,1:T_proj));
    hold on
    plot(1:T,dailyincidence(locs(i),1:T),'rx');
    xlim([1,T_proj])
%     xlim([1,T])
    title(countyfips{locs(i),2}{1})
end
set(gcf,'Position',[100,100,800,600])
figure(2)
temp=squeeze(sum(obs_proj,1));
plot(1:T_proj,temp(:,1:T_proj));
hold on
plot(1:T,sum(dailyincidence(:,1:T)),'rx');
xlim([1,T_proj])
% xlim([1,T])

death_proj=death_proj_5_2xhold;
figure(3)
for i=1:length(locs)
    subplot(4,4,i)
    temp=squeeze(death_proj(locs(i),:,:));
    plot(1:T_proj,temp(:,1:T_proj));
    hold on
    plot(1:T,dailydeaths(locs(i),1:T),'rx');
    xlim([1,T_proj])
%     xlim([1,T])
    title(countyfips{locs(i),2}{1})
end
set(gcf,'Position',[100,100,800,600])
figure(4)
temp=squeeze(sum(death_proj,1));
plot(1:T_proj,temp(:,1:T_proj));
hold on
plot(1:T,sum(dailydeaths(:,1:T)),'rx');
xlim([1,T_proj])
% xlim([1,T])
