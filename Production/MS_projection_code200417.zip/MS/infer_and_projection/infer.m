function infer()
% mex model_eakf.cpp
Td=9;%average reporting delay
a=1.85;%shape parameter of gamma distribution
b=Td/a;%scale parameter of gamma distribution
rnds=ceil(gamrnd(a,b,1e4,1));%pre-generate gamma random numbers

Td_death=9;%average delay of death
a=1.85;%shape parameter of gamma distribution
b=Td_death/a;%scale parameter of gamma distribution
rnds_d=ceil(gamrnd(a,b,1e4,1))+7;%pre-generate gamma random numbers

load commutedata
load population
num_loc=size(part,1)-1;
num_mp=size(nl,1);

load dailyincidence
load dailydeaths
%smooth the data: 3 day moving average
for l=1:num_loc
    dailyincidence(l,:)=smooth(dailyincidence(l,:),3);
    dailydeaths(l,:)=smooth(dailydeaths(l,:),3);
end

load deathrate
num_times=size(dailyincidence,2);%total length of data
T=num_times+6*7;%projection for 6 weeks
obs_case=dailyincidence;
obs_death=dailydeaths;
incidence=dailyincidence(:,1:22);%from 02/21 to 03/13, to initialize

%set OEV
OEV_case=max(9,obs_case.^2/4);
OEV_death=max(9,obs_death.^2/4);

num_ens=100;%number of ensemble
infection_proj=zeros(num_loc,num_ens,T);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%run model unitl March 10, day 19
[S,E,Ir,Iu,Seedc]=initialize(nl,part,C,num_ens,incidence);
obs_temp=zeros(num_loc,num_ens,T);%records of reported cases
death_temp=zeros(num_loc,num_ens,T);%records of death
load('parafit1')
%initialize parameters
[para,paramax,paramin,betamap,alphamap]=initializepara_eakf(dailyincidence,num_ens,parafit);

paramax_ori=paramax;
paramin_ori=paramin;
%%%%%%%%%%%%inflate variables and parameters
lambda=8;
para=mean(para,2)*ones(1,num_ens)+lambda*(para-mean(para,2)*ones(1,num_ens));
para=checkbound_para(para,paramax,paramin);
S=mean(S,2)*ones(1,num_ens)+lambda*(S-mean(S,2)*ones(1,num_ens));
E=mean(E,2)*ones(1,num_ens)+lambda*(E-mean(E,2)*ones(1,num_ens));
Ir=mean(Ir,2)*ones(1,num_ens)+lambda*(Ir-mean(Ir,2)*ones(1,num_ens));
Iu=mean(Iu,2)*ones(1,num_ens)+lambda*(Iu-mean(Iu,2)*ones(1,num_ens));
[S,E,Ir,Iu]=checkbound(S,E,Ir,Iu,C);
%fix Z, D and theta
%Z
para(1,:)=median(parafit(3,:))*ones(1,num_ens);
%D
para(2,:)=median(parafit(4,:))*ones(1,num_ens);
%theta
para(4,:)=median(parafit(6,:))*ones(1,num_ens);


for t=1:22%run unitl March 13
    t
    tic
    %%%%%%%%%%%seeding
    if t<=size(Seedc,2)
        [S,E,Ir,Iu]=seeding(S,E,Ir,Iu,nl,part,C,Seedc,t);
    end
    for k=1:num_ens
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C,Cave,S(:,k),E(:,k),Ir(:,k),Iu(:,k),para(:,k),betamap,alphamap);
        for l=1:num_loc
            infection_proj(l,k,t)=min(sum(dailyIr_temp(part(l):part(l+1)-1))+sum(dailyIu_temp(part(l):part(l+1)-1)),500);
        end
        %reporting delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=min(dailyIr_temp(j),100);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_temp(l,k,t+rnd(h))=obs_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %death delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=min(round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l)),10);
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_temp(l,k,t+rnd(h))=death_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end
    toc
end

parastd=std(para(1:6,:),0,2);

%reduce inter-county commuting by half
reduce_commute=0.5;
for l=1:num_loc
    for j=part(l)+1:part(l+1)-1
        C(part(l))=C(part(l))+round(reduce_commute*C(j));
        Cave(part(l))=Cave(part(l))+round(reduce_commute*Cave(j));
        C(j)=round((1-reduce_commute)*C(j));
        Cave(j)=round((1-reduce_commute)*Cave(j));
    end
end

for l=1:num_loc
    for j=part(l)+1:part(l+1)-1
        S(part(l))=S(part(l))+round(reduce_commute*S(j));
        S(j)=round((1-reduce_commute)*S(j));
        E(part(l))=E(part(l))+round(reduce_commute*E(j));
        E(j)=round((1-reduce_commute)*E(j));
        Ir(part(l))=Ir(part(l))+round(reduce_commute*Ir(j));
        Ir(j)=round((1-reduce_commute)*Ir(j));
        Iu(part(l))=Iu(part(l))+round(reduce_commute*Iu(j));
        Iu(j)=round((1-reduce_commute)*Iu(j));
    end
end

%EAKF
lambda=1.5;%inflation
lambda_variable=1.1;
num_para=size(para,1);
para_post=zeros(num_para,num_ens,num_times);
for t=23:num_times%start from March 14
    t
    tic
    %inflation
    para(1:6,:)=mean(para(1:6,:),2)*ones(1,num_ens)+lambda*(para(1:6,:)-mean(para(1:6,:),2)*ones(1,num_ens));
    para=checkbound_para(para,paramax,paramin);
    parastdcnt=std(para(1:6,:),0,2);
    for i=1:6
        if min(parastdcnt(i)/parastd(i))<1%redistribute
            SIG=(paramax(i)-paramin(i)).^2/9;%initial covariance of parameters%v4
            Sigma=diag(SIG);
            theta_last=mean(para(i,:),2);
            para(i,:)=mvnrnd(theta_last',Sigma,num_ens)';%generate parameters
        end
        paramax(i)=min(mean(para(i,:))*1.25,paramax_ori(i));
        paramin(i)=max(mean(para(i,:))*0.75,paramin_ori(i));
    end
    para=checkbound_paraini(para,paramax,paramin);
    S=mean(S,2)*ones(1,num_ens)+lambda_variable*(S-mean(S,2)*ones(1,num_ens));
    E=mean(E,2)*ones(1,num_ens)+lambda_variable*(E-mean(E,2)*ones(1,num_ens));
    Ir=mean(Ir,2)*ones(1,num_ens)+lambda_variable*(Ir-mean(Ir,2)*ones(1,num_ens));
    Iu=mean(Iu,2)*ones(1,num_ens)+lambda_variable*(Iu-mean(Iu,2)*ones(1,num_ens));
    [S,E,Ir,Iu]=checkbound(S,E,Ir,Iu,C);
    %fix Z, D and theta
    %Z
    para(1,:)=median(parafit(3,:))*ones(1,num_ens);
    %D
    para(2,:)=median(parafit(4,:))*ones(1,num_ens);
    %theta
    para(4,:)=median(parafit(6,:))*ones(1,num_ens);
    %%%%%%%%%%%%%%%%%%
    S_temp=S; E_temp=E; Ir_temp=Ir; Iu_temp=Iu;
    %integrate forward one step
    dailyIr_prior=zeros(num_mp,num_ens);
    dailyIr_post=zeros(num_mp,num_ens);
    dailyIu_prior=zeros(num_mp,num_ens);
    dailyIu_post=zeros(num_mp,num_ens);
    for k=1:num_ens%run for each ensemble member
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C,Cave,S(:,k),E(:,k),Ir(:,k),Iu(:,k),para(:,k),betamap,alphamap);
        dailyIr_prior(:,k)=dailyIr_temp;
        dailyIu_prior(:,k)=dailyIu_temp;
        %reporting delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=dailyIr_temp(j);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_temp(l,k,t+rnd(h))=obs_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %death delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l));
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_temp(l,k,t+rnd(h))=death_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%
    %integrate forward for six days, prepare for observation
    Tproj=min(6,num_times-t+1);
    obs_temp1=obs_temp;
    death_temp1=death_temp;
    for t1=t:t+Tproj-1
        for k=1:num_ens%run for each ensemble member
            [S_temp(:,k),E_temp(:,k),Ir_temp(:,k),Iu_temp(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C,Cave,S_temp(:,k),E_temp(:,k),Ir_temp(:,k),Iu_temp(:,k),para(:,k),betamap,alphamap);
            %reporting delay
            for l=1:num_loc
                for j=part(l):part(l+1)-1
                    inci=dailyIr_temp(j);
                    if inci>0
                        rnd=datasample(rnds,inci);
                        for h=1:length(rnd)
                            if (t+rnd(h)<=T)
                                obs_temp1(l,k,t+rnd(h))=obs_temp1(l,k,t+rnd(h))+1;
                            end
                        end 
                    end
                end
            end
            %death delay
            for l=1:num_loc
                for j=part(l):part(l+1)-1
                    inci=round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l));
                    if inci>0
                        rnd=datasample(rnds_d,inci);
                        for h=1:length(rnd)
                            if (t+rnd(h)<=T)
                                death_temp1(l,k,t+rnd(h))=death_temp1(l,k,t+rnd(h))+1;
                            end
                        end 
                    end
                end
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for t1=t+Tproj-1
        obs_ens=obs_temp1(:,:,t1);%observation at t1, prior
        death_ens=death_temp1(:,:,t1);%death at t1, prior
        %loop through local observations
        for l=1:num_loc
            %%%%%%%%%%%%%%%%%%%death
            %Get the variance of the ensemble
            obs_var = OEV_death(l,t1);
            prior_var = var(death_ens(l,:));
            post_var = prior_var*obs_var/(prior_var+obs_var);
            if prior_var==0%if degenerate
                post_var=1e-3;
                prior_var=1e-3;
            end
            prior_mean = mean(death_ens(l,:));
            post_mean = post_var*(prior_mean/prior_var + obs_death(l,t1)/obs_var);
            %%%% Compute alpha and adjust distribution to conform to posterior moments
            alpha = (obs_var/(obs_var+prior_var)).^0.5;
            dy = post_mean + alpha*(death_ens(l,:)-prior_mean)-death_ens(l,:);
            %Loop over each state variable (connected to location l)
            %adjust related metapopulation
            neighbors=part(l):part(l+1)-1;%metapopulation live in l
            neighbors1=find(nl==l);%%metapopulation work in l
            neighbors=union(neighbors1,neighbors);
            for h=1:length(neighbors)
                j=neighbors(h);
                %S
                temp=S(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                S(j,:)=S(j,:)+dx;
                %E
                temp=E(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                E(j,:)=E(j,:)+dx;
                %Ir
                temp=Ir(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                Ir(j,:)=Ir(j,:)+dx;
                %Iu
                temp=Iu(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                Iu(j,:)=Iu(j,:)+dx;
                %dailyIr
                temp=dailyIr_prior(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                dailyIr_post(j,:)=round(max(dailyIr_prior(j,:)+dx,0));
                %dailyIu
                temp=dailyIu_prior(j,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                dailyIu_post(j,:)=round(max(dailyIu_prior(j,:)+dx,0));
            end
            if (sum(obs_death(l,1:t1))>0)
            %adjust parameters
            for i=3%Z,D,mu,theta
                temp=para(i,:);
                A=cov(temp,death_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                para(i,:)=para(i,:)+dx;
            end
            %adjust alpha
            temp=para(alphamap(l),:);
            A=cov(temp,death_ens(l,:));
            rr=A(2,1)/prior_var;
            dx=rr*dy;
            para(alphamap(l),:)=para(alphamap(l),:)+dx;
            %adjust beta
            temp=para(betamap(l),:);
            A=cov(temp,death_ens(l,:));
            rr=A(2,1)/prior_var;
            dx=rr*dy;
            para(betamap(l),:)=para(betamap(l),:)+dx;
            end
            para=checkbound_para(para,paramax,paramin);
            
            %%%%%%%%%%%%%%%%%%%case
            %Get the variance of the ensemble
            obs_var = OEV_case(l,t1);
            prior_var = var(obs_ens(l,:));
            post_var = prior_var*obs_var/(prior_var+obs_var);
            if prior_var==0%if degenerate
                post_var=1e-3;
                prior_var=1e-3;
            end
            prior_mean = mean(obs_ens(l,:));
            post_mean = post_var*(prior_mean/prior_var + obs_case(l,t1)/obs_var);
            %%%% Compute alpha and adjust distribution to conform to posterior moments
            alpha = (obs_var/(obs_var+prior_var)).^0.5;
            dy = post_mean + alpha*(obs_ens(l,:)-prior_mean)-obs_ens(l,:);
            %Loop over each state variable (connected to location l)
            %adjust related metapopulation
            neighbors=part(l):part(l+1)-1;%metapopulation live in l
            neighbors1=find(nl==l);%%metapopulation work in l
            neighbors=union(neighbors1,neighbors);
            for h=1:length(neighbors)
                j=neighbors(h);
                %S
                temp=S(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                S(j,:)=S(j,:)+dx;
                %E
                temp=E(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                E(j,:)=E(j,:)+dx;
                %Ir
                temp=Ir(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                Ir(j,:)=Ir(j,:)+dx;
                %Iu
                temp=Iu(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                Iu(j,:)=Iu(j,:)+dx;
                %dailyIr
                temp=dailyIr_prior(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                dailyIr_post(j,:)=round(max(dailyIr_prior(j,:)+dx,0));
                %dailyIu
                temp=dailyIu_prior(j,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                dailyIu_post(j,:)=round(max(dailyIu_prior(j,:)+dx,0));
            end
            if (sum(obs_case(l,1:t1))>0)
            %adjust parameters
            for i=3%Z,D,mu,theta
                temp=para(i,:);
                A=cov(temp,obs_ens(l,:));
                rr=A(2,1)/prior_var;
                dx=rr*dy;
                para(i,:)=para(i,:)+dx;
            end
            %adjust alpha
            temp=para(alphamap(l),:);
            A=cov(temp,obs_ens(l,:));
            rr=A(2,1)/prior_var;
            dx=rr*dy;
            para(alphamap(l),:)=para(alphamap(l),:)+dx;
            %adjust beta
            temp=para(betamap(l),:);
            A=cov(temp,obs_ens(l,:));
            rr=A(2,1)/prior_var;
            dx=rr*dy;
            para(betamap(l),:)=para(betamap(l),:)+dx;
            end
            para=checkbound_para(para,paramax,paramin);
        end 
    end
    
    for k=1:num_ens
        %update obs_temp
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=dailyIr_post(j,k);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_temp(l,k,t+rnd(h))=obs_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %update death_temp
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=round((dailyIr_post(j,k)+dailyIu_post(j,k))*deathrate(l));
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_temp(l,k,t+rnd(h))=death_temp(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end

    [S,E,Ir,Iu]=checkbound(S,E,Ir,Iu,C);
    para_post(:,:,t)=para;
    %%%%prepare projection
    for k=1:num_ens
        %total infection
        for l=1:num_loc
            infection_proj(l,k,t)=sum(dailyIr_post(part(l):part(l+1)-1,k))+sum(dailyIu_post(part(l):part(l+1)-1,k));
        end
    end
   toc
end

S_start=S; E_start=E; Ir_start=Ir; Iu_start=Iu;
obs_temp_start=obs_temp;%records of reported cases
death_temp_start=death_temp;%records of reported cases
infection_proj_start=infection_proj;

%no intervention
%%%%%%%%%%%%%%%%%%%%%%%
S=S_start; E=E_start; Iu=Iu_start; Ir=Ir_start;
obs_proj=obs_temp_start;
death_proj=death_temp_start;
infection_proj=infection_proj_start;
paratemp=para_post(:,:,end);
for t=num_times+1:T
    t
    tic
    for k=1:num_ens%run for each ensemble member
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C,Cave,S(:,k),E(:,k),Ir(:,k),Iu(:,k),paratemp(:,k),betamap,alphamap);
        for l=1:num_loc
            infection_proj(l,k,t)=sum(dailyIr_temp(part(l):part(l+1)-1))+sum(dailyIu_temp(part(l):part(l+1)-1));
        end
        %reporting delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=dailyIr_temp(j);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_proj(l,k,t+rnd(h))=obs_proj(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %death delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l));
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_proj(l,k,t+rnd(h))=death_proj(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end
    toc
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%intervention
threshold=10;
%%%%%%%%%%%%%%%%%%%%%%%
reduce=0.2;
S=S_start; E=E_start; Iu=Iu_start; Ir=Ir_start;
obs_proj_20=obs_temp_start;
death_proj_20=death_temp_start;
infection_proj_20=infection_proj_start;
paratemp=para_post(:,:,end);

stopreduce=zeros(num_loc,1);
for t=num_times+1:T
    tdiff=t-(num_times+1);
    %reduce beta
    if mod(tdiff,7)==0
        %decide whether to stop reduction
        for l=1:num_loc
            if t-1<=num_times
                weeklycase=sum(dailyincidence(l,t-7:t-1));%latest week
            else
                temp=sum(obs_proj_20(l,:,t-7:t-1),3);
                weeklycase=median(temp);%latest week
            end
            if t-8<=num_times
                weeklycaselast=sum(dailyincidence(l,t-14:t-8));%two weeks ago
            else
                temp=sum(obs_proj_20(l,:,t-14:t-8),3);
                weeklycaselast=median(temp);%two weeks ago
            end
            if weeklycase<weeklycaselast
                stopreduce(l)=1;
            else
                stopreduce(l)=0;
            end
            if (weeklycase>=threshold)&&(stopreduce(l)==0)
                paratemp(betamap(l),:)=paratemp(betamap(l),:)*(1-reduce);
            end
        end
    end
    t
    tic
    for k=1:num_ens%run for each ensemble member
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C,Cave,S(:,k),E(:,k),Ir(:,k),Iu(:,k),paratemp(:,k),betamap,alphamap);
        for l=1:num_loc
            infection_proj_20(l,k,t)=sum(dailyIr_temp(part(l):part(l+1)-1))+sum(dailyIu_temp(part(l):part(l+1)-1));
        end
        %reporting delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=dailyIr_temp(j);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_proj_20(l,k,t+rnd(h))=obs_proj_20(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %death delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l));
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_proj_20(l,k,t+rnd(h))=death_proj_20(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end
    toc
end

%%%%%%%%%%%%%%%%%%%%%%%
reduce=0.3;
S=S_start; E=E_start; Iu=Iu_start; Ir=Ir_start;
obs_proj_30=obs_temp_start;
death_proj_30=death_temp_start;
infection_proj_30=infection_proj_start;
paratemp=para_post(:,:,end);

stopreduce=zeros(num_loc,1);
for t=num_times+1:T
    tdiff=t-(num_times+1);
    %reduce beta
    if mod(tdiff,7)==0
        %decide whether to stop reduction
        for l=1:num_loc
            if t-1<=num_times
                weeklycase=sum(dailyincidence(l,t-7:t-1));%latest week
            else
                temp=sum(obs_proj_30(l,:,t-7:t-1),3);
                weeklycase=median(temp);%latest week
            end
            if t-8<=num_times
                weeklycase=sum(dailyincidence(l,t-14:t-8));%two weeks ago
            else
                temp=sum(obs_proj_30(l,:,t-14:t-8),3);
                weeklycaselast=median(temp);%two weeks ago
            end
            if weeklycase<weeklycaselast
                stopreduce(l)=1;
            else
                stopreduce(l)=0;
            end
            if (weeklycase>=threshold)&&(stopreduce(l)==0)
                paratemp(betamap(l),:)=paratemp(betamap(l),:)*(1-reduce);
            end
        end
    end
    t
    tic
    for k=1:num_ens%run for each ensemble member
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C,Cave,S(:,k),E(:,k),Ir(:,k),Iu(:,k),paratemp(:,k),betamap,alphamap);
        for l=1:num_loc
            infection_proj_30(l,k,t)=sum(dailyIr_temp(part(l):part(l+1)-1))+sum(dailyIu_temp(part(l):part(l+1)-1));
        end
        %reporting delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=dailyIr_temp(j);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_proj_30(l,k,t+rnd(h))=obs_proj_30(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %death delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l));
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_proj_30(l,k,t+rnd(h))=death_proj_30(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end
    toc
end

%%%%%%%%%%%%%%%%%%%%%%%
reduce=0.4;
S=S_start; E=E_start; Iu=Iu_start; Ir=Ir_start;
obs_proj_40=obs_temp_start;
death_proj_40=death_temp_start;
infection_proj_40=infection_proj_start;
paratemp=para_post(:,:,end);

stopreduce=zeros(num_loc,1);
for t=num_times+1:T
    tdiff=t-(num_times+1);
    %reduce beta
    if mod(tdiff,7)==0
        %decide whether to stop reduction
        for l=1:num_loc
            if t-1<=num_times
                weeklycase=sum(dailyincidence(l,t-7:t-1));%latest week
            else
                temp=sum(obs_proj_40(l,:,t-7:t-1),3);
                weeklycase=median(temp);%latest week
            end
            if t-8<=num_times
                weeklycase=sum(dailyincidence(l,t-14:t-8));%two weeks ago
            else
                temp=sum(obs_proj_40(l,:,t-14:t-8),3);
                weeklycaselast=median(temp);%two weeks ago
            end
            if weeklycase<weeklycaselast
                stopreduce(l)=1;
            else
                stopreduce(l)=0;
            end
            if (weeklycase>=threshold)&&(stopreduce(l)==0)
                paratemp(betamap(l),:)=paratemp(betamap(l),:)*(1-reduce);
            end
        end
    end
    t
    tic
    for k=1:num_ens%run for each ensemble member
        [S(:,k),E(:,k),Ir(:,k),Iu(:,k),dailyIr_temp,dailyIu_temp]=model_eakf(nl,part,C,Cave,S(:,k),E(:,k),Ir(:,k),Iu(:,k),paratemp(:,k),betamap,alphamap);
        for l=1:num_loc
            infection_proj_40(l,k,t)=sum(dailyIr_temp(part(l):part(l+1)-1))+sum(dailyIu_temp(part(l):part(l+1)-1));
        end
        %reporting delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=dailyIr_temp(j);
                if inci>0
                    rnd=datasample(rnds,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            obs_proj_40(l,k,t+rnd(h))=obs_proj_40(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
        %death delay
        for l=1:num_loc
            for j=part(l):part(l+1)-1
                inci=round((dailyIr_temp(j)+dailyIu_temp(j))*deathrate(l));
                if inci>0
                    rnd=datasample(rnds_d,inci);
                    for h=1:length(rnd)
                        if (t+rnd(h)<=T)
                            death_proj_40(l,k,t+rnd(h))=death_proj_40(l,k,t+rnd(h))+1;
                        end
                    end 
                end
            end
        end
    end
    toc
end



save(['Projection_extend'],'obs_case','obs_death','para_post','obs_temp','death_temp',...
    'obs_proj','infection_proj','death_proj',...
    'obs_proj_20','infection_proj_20','death_proj_20',...
    'obs_proj_30','infection_proj_30','death_proj_30',...
    'obs_proj_40','infection_proj_40','death_proj_40');


function para = checkbound_paraini(para,paramax,paramin)
for i=1:size(para,1)
    temp=para(i,:);
    index=(temp<paramin(i))|(temp>paramax(i));
    index_out=find(index>0);
    index_in=find(index==0);
    %redistribute out bound ensemble members
    para(i,index_out)=datasample(para(i,index_in),length(index_out));
end


function para = checkbound_para(para,paramax,paramin)
for i=1:size(para,1)
    para(i,para(i,:)<paramin(i))=paramin(i)*(1+0.1*rand(sum(para(i,:)<paramin(i)),1));
    para(i,para(i,:)>paramax(i))=paramax(i)*(1-0.1*rand(sum(para(i,:)>paramax(i)),1));
end

function [S,E,Ir,Iu]=checkbound(S,E,Ir,Iu,C)
for k=1:size(S,2)
    S(S(:,k)<0,k)=0; E(E(:,k)<0,k)=0; Ir(Ir(:,k)<0,k)=0; Iu(Iu(:,k)<0,k)=0;
    S(S(:,k)>C,k)=C(S(:,k)>C);
    E(E(:,k)>C,k)=C(E(:,k)>C);
    Ir(Ir(:,k)>C,k)=C(Ir(:,k)>C);
    Iu(Iu(:,k)>C,k)=C(Iu(:,k)>C);
end
