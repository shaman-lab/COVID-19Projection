function outputprojection()
load ('../infer_and_projection/Projection_extend.mat');

outputinci(obs_proj,infection_proj,death_proj,'../output/Projection_nointerv.csv');
outputinci(obs_proj_20,infection_proj_20,death_proj_20,'../output/Projection_80contact.csv');
outputinci(obs_proj_30,infection_proj_30,death_proj_30,'../output/Projection_70contact.csv');
outputinci(obs_proj_40,infection_proj_40,death_proj_40,'../output/Projection_60contact.csv');


function outputinci(obs_proj,infection_proj,death_proj,filename)
load countyfips
data=obs_proj;
data1=infection_proj;
data2=death_proj;
num_times=size(data,3);
num_loc=size(data,1);
T0=datetime('21/02/20','InputFormat','dd/MM/yy');
fid=fopen(filename,'w');
header=['county,fips,Date,confirmed_2.5,confirmed_25,confirmed_50,confirmed_75,confirmed_97.5'];
header=[header,',infection_2.5,infection_25,inection_50,infection_75,infection_97.5'];
header=[header,',death_2.5,death_25,death_50,death_75,death_97.5\n'];
fprintf(fid,header);
load ('../infer_and_projection/dailyincidence.mat');
T_proj=size(dailyincidence,2);

for t=T_proj+1:num_times
    t
    for i=1:num_loc
        fprintf(fid,'%s,%s,%s',countyfips{i,2}{1},countyfips{i,3}{1},datestr(T0+t-1,'mm/dd/yy'));
        temp=squeeze(data(i,:,t));
        mid=round(median(temp));llow=round(prctile(temp,2.5));low=round(prctile(temp,25));
        up=round(prctile(temp,75));upp=round(prctile(temp,97.5));
        fprintf(fid,',%d,%d,%d,%d,%d',llow,low,mid,up,upp);
        temp=squeeze(data1(i,:,t));
        mid=round(median(temp));llow=round(prctile(temp,2.5));low=round(prctile(temp,25));
        up=round(prctile(temp,75));upp=round(prctile(temp,97.5));
        fprintf(fid,',%d,%d,%d,%d,%d',llow,low,mid,up,upp);
        temp=squeeze(data2(i,:,t));
        mid=round(median(temp));llow=round(prctile(temp,2.5));low=round(prctile(temp,25));
        up=round(prctile(temp,75));upp=round(prctile(temp,97.5));
        fprintf(fid,',%d,%d,%d,%d,%d',llow,low,mid,up,upp);
        fprintf(fid,'\n');
    end

end
fclose(fid);