function [para,paramax,paramin,betamap,alphamap]=initializepara_eakf(dailyincidence,num_ens,parafit)
%Z,D,mu,theta,alpha1,alpha2,beta1,...,beta200,beta201,...,beta216
Zlow=2;Zup=5;%latency period
Dlow=2;Dup=5;%infectious period
mulow=0.0;muup=0.6;%relative transmissibility
thetalow=0.01;thetaup=0.3;%movement factor
alphalow=0.05;alphaup=0.25;%reporting rate
betalow=0.0;betaup=2.5;%transmission rate

%selected areas
num_loc=size(dailyincidence,1);
ranks=zeros(num_loc,2);
ranks(:,1)=(1:num_loc)';
ranks(:,2)=sum(dailyincidence,2);
ranks=sortrows(ranks,-2);

%define alpha
selected=ranks(1:200,1);
alphamap=ones(num_loc,1)*6;%all others, alpha2
alphamap(selected)=5;%top 200, alpha1

%define beta
betamap=zeros(num_loc,1);%beta0 for low-case counties
betamap(selected)=6+(1:length(selected))';

load popd
PD=log10(popd);
PD_median=median(PD);

factors=ones(length(selected)+16,1);
scale=0.6;
for i=1:length(selected)
    loc=selected(i);
    factors(i)=max(1,PD(loc)/PD_median*scale);
end

notselected=(1:num_loc)';
notselected(selected)=[];
total=sum(dailyincidence,2);
totalrank(:,1)=notselected;
totalrank(:,2)=total(notselected);
totalrank=sortrows(totalrank,-2);
PDrank(:,1)=notselected;
PDrank(:,2)=PD(notselected);
PDrank=sortrows(PDrank,-2);

for i=1:length(notselected)
    l=notselected(i);
    caserankid=find(totalrank(:,1)==l);
    caserankid=ceil(caserankid/(length(notselected)/4));
    PDrankid=find(PDrank(:,1)==l);
    PDrankid=ceil(PDrankid/(length(notselected)/4));
    betamap(l)=206+(caserankid-1)*4+PDrankid;
end

%Z,D,mu,theta,alpha1,alpha2,beta1,...,beta200,beta201,...,beta216
paramin=[Zlow;Dlow;mulow;thetalow;ones(2,1)*alphalow;ones(length(selected)+16,1)*betalow];
paramax=[Zup;Dup;muup;thetaup;ones(2,1)*alphaup;ones(length(selected)+16,1)*betaup];

para=zeros(size(paramin,1),num_ens);

%parafit:beta;mu;Z;D;alpha;theta
%Z
para(1,:)=median(parafit(3,:))*ones(1,num_ens);
%D
para(2,:)=median(parafit(4,:))*ones(1,num_ens);
%mu
para(3,:)=parafit(2,ceil(rand(1,num_ens)*size(parafit,2)));
%theta
para(4,:)=median(parafit(6,:))*ones(1,num_ens);
%alpha
for i=5:6
    para(i,:)=parafit(5,ceil(rand(1,num_ens)*size(parafit,2)));
end
%beta
for i=7:size(paramin,1)
    para(i,:)=parafit(1,ceil(rand(1,num_ens)*size(parafit,2)))*factors(i-6);
end
