function runprojection()
cd data_extraction
url = 'https://usafactsstatic.blob.core.windows.net/public/data/covid-19/covid_confirmed_usafacts.csv';
urlwrite (url, 'covid_confirmed_usafacts.csv');
url = 'https://usafactsstatic.blob.core.windows.net/public/data/covid-19/covid_deaths_usafacts.csv';
urlwrite (url, 'covid_deaths_usafacts.csv');
compiledata()
compiledeathdata()
cd ../infer_and_projection
infer()
cd ../caseprojection
outputprojection()
cd ..